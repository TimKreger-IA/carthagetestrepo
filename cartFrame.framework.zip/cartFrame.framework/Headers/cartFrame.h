//
//  cartFrame.h
//  cartFrame
//
//  Created by Tim Kreger on 4/02/2016.
//  Copyright © 2016 Intelematics. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for cartFrame.
FOUNDATION_EXPORT double cartFrameVersionNumber;

//! Project version string for cartFrame.
FOUNDATION_EXPORT const unsigned char cartFrameVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <cartFrame/PublicHeader.h>


